// This is a product of the Jason Melendez Software Distribution
// legit.js

